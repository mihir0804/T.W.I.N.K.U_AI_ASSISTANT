import subprocess
import os
import time

# ── App aliases ───────────────────────────────────────────
APP_ALIASES = {
    # Browsers
    "chrome":                "chrome",
    "google chrome":         "chrome",
    "firefox":               "firefox",
    "edge":                  "msedge",
    "microsoft edge":        "msedge",
    "brave":                 "brave",

    # System tools
    "notepad":               "notepad",
    "notepad++":             "notepad++",
    "calculator":            "calc",
    "calc":                  "calc",
    "cmd":                   "cmd",
    "command prompt":        "cmd",
    "terminal":              "wt",          # Windows Terminal
    "task manager":          "taskmgr",
    "file explorer":         "explorer",
    "explorer":              "explorer",
    "paint":                 "mspaint",
    "ms paint":              "mspaint",
    "wordpad":               "wordpad",
    "snipping tool":         "snippingtool",
    "control panel":         "control",
    "settings":              "ms-settings:",

    # Dev tools
    "vscode":                "code",
    "vs code":               "code",
    "visual studio code":    "code",
    "pycharm":               "pycharm64",
    "git bash":              "git bash",
    "postman":               "postman",

    # ✅ FIX: UWP Apps — inhe PowerShell se kholna padta hai
    # cmd /c start se ye nahi khulti thi — YAHI MAIN BUG THA
    "whatsapp":   "shell:AppsFolder\\5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App",
    "telegram":   "telegram",
    "discord":    "discord",
    "zoom":       "zoom",
    "teams":      "teams",
    "microsoft teams": "teams",
    "slack":      "slack",
    "spotify":    "shell:AppsFolder\\SpotifyAB.SpotifyMusic_zpdnekdrzrea0!Spotify",

    # Office
    "word":                  "winword",
    "microsoft word":        "winword",
    "excel":                 "excel",
    "microsoft excel":       "excel",
    "powerpoint":            "powerpnt",
    "microsoft powerpoint":  "powerpnt",
    "outlook":               "outlook",

    # Media
    "vlc":                   "vlc",
    "vlc media player":      "vlc",
    "obs":                   "obs64",
    "obs studio":            "obs64",
}
#UWP shell:path--- inhe power shell se kholna padta hai, direct cmd se nahi khulte
#UWP apps ke liye "shell:AppsFolder\\PackageFamilyName!App"
UWP_PREFIXES = ["shell:AppsFolder\\", "ms-settings:", "shell:"]

PS=r"C:\Windows\System32\windowsPowerShell\v1.0\powershell.exe"

def is_uwp(path: str) -> bool:
    return any(path.startswith(prefix) for prefix in UWP_PREFIXES)

def open_app(app_name:str) -> str:
    name = app_name.lower().strip()

    search = APP_ALIASES.get(name)
    if not search:
        for key, value in APP_ALIASES.items():
            if name in key or key in name:
                search = value
                break
    
    if not search:
        search = name
        
    print(f"opening: '{search}' (requested as '{app_name}')")
    
    if is_uwp(search):
        try:
            subprocess.Popen([PS, "-NoProfile", "-WindowStyle", "Hidden", "-Command", f"Start-Process '{search}'"], 
                             creationflags=subprocess.CREATE_NO_WINDOW)
            return f"हाँ जान, {app_name} अभी खोलती हूँ! ❤️"
        except Exception as e:
            print("UWP method failed, trying direct launch...", e)

    try:
        subprocess.Popen(["cmd", "/c", "start", "", search], shell=False, creationflags=subprocess.CREATE_NO_WINDOW)
        return f"हाँ जान, {app_name} अभी खोलती हूँ! ❤️"
    except Exception as e1:
        print("Direct launch failed, trying shell=True...", e1)
        try:
            subprocess.Popen(search, shell=True, creationflags=subprocess.CREATE_NO_WINDOW)
            return f"हाँ जान, {app_name} अभी खोलती हूँ! ❤️"
        except Exception as e2:
            print("All conventional methods failed...", e2)
            try:
                cmd = f"(Get-AppxPackage -Name *{search}*).PackageFamilyName"
                r = subprocess.run([PS, "-NoProfile", "-Command", cmd], capture_output=True, text=True, timeout=8)
                package_family = r.stdout.strip()
                if package_family:
                    cmd_app_id = f"(Get-AppxPackageManifest (Get-AppxPackage -Name '{package_family}')).Package.Applications.Application.Id"
                    r_id = subprocess.run([PS, "-NoProfile", "-Command", cmd_app_id], capture_output=True, text=True, timeout=5)
                    app_id = r_id.stdout.strip()
                    if app_id:
                        full_id = f"{package_family}!{app_id}"
                        subprocess.Popen([PS, "-NoProfile", "-WindowStyle", "Hidden", "-Command", f"Start-Process 'shell:AppsFolder\\{full_id}'"], 
                                         creationflags=subprocess.CREATE_NO_WINDOW)
                        return f"हाँ जान, {app_name} अभी खोलती हूँ! ❤️"
            except Exception as e3:
                print("UWP lookup method failed...", e3)
            
            return f"माफ करना जान, मैं {app_name} नहीं खोल पा रही हूँ 😔 शायद ये app मेरे लिए बहुत मुश्किल है... 💕"

if __name__ == "__main__":
    # Test cases
    print(open_app("notepad"))
    print(open_app("whatsapp"))
