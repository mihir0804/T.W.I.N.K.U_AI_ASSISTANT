# main.py — Fixed version
# ✅ FIX 1: Tool calling add kiya — transcript-only approach unreliable tha
# ✅ FIX 2: inputTranscription + outputTranscript dono handle kiye
# ✅ FIX 3: extract_app_name improved — Hindi triggers + better matching
# ✅ FIX 4: Audio jitter buffer fix — stutter nahi hoga
# ✅ FIX 5: Reconnect logic add kiya

import asyncio
import base64
import json
import numpy as np
import sounddevice as sd
import websockets
from prompt import ARIA_PROMPT
from app import open_app, APP_ALIASES

# ── Config ────────────────────────────────────────────────
API_KEY = "AIzaSyC8zU6YpdGWRxvxWCIgQkOUTlqfUx2hDKk"
WS_URL  = ("wss://generativelanguage.googleapis.com/ws/"
           "google.ai.generativelanguage.v1beta."
           "GenerativeService.BidiGenerateContent")

MIC_RATE = 16000
SPK_RATE = 24000
FRAMES   = int(MIC_RATE * 20 / 1000)

# ── Tool Declaration ─────────────────────────────────────
# ✅ FIX 1: Pehle sirf transcript se app open karte the — bahut unreliable
# Ab Gemini khud tool call karega jab user app open karne ko bole
# Yeh approach ARIA v4 (tools.py) wali hai — 100% reliable
OPEN_APP_TOOL = {
    "name": "open_app",
    "description": (
        "Koi bhi application/software open karo user ke PC pe. "
        "Jab bhi user koi app open karne ko bole — "
        "'chrome kholo', 'notepad open karo', 'whatsapp chalao', "
        "'calculator open karo', 'spotify chalaao' — "
        "toh yeh tool call karo. "
        "App name exactly waise do jaise user ne bola."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "app_name": {
                "type": "string",
                "description": "App ka naam jo open karna hai, e.g. 'chrome', 'notepad', 'whatsapp'"
            }
        },
        "required": ["app_name"]
    }
}

# ── Setup ─────────────────────────────────────────────────
SETUP = {
    "setup": {
        "model": "models/gemini-2.5-flash-native-audio-preview-12-2025",
        "generation_config": {
            "temperature": 0.7,
            "response_modalities": ["AUDIO"],
            "speech_config": {
                "voice_config": {
                    "prebuilt_voice_config": {"voice_name": "Aoede"}
                }
            }
        },
        "input_audio_transcription":  {},   # User speech transcript
        "output_audio_transcription": {},   # ARIA speech transcript
        "system_instruction": {"parts": [{"text": ARIA_PROMPT}]},
        # ✅ FIX 1: Tool declaration — Gemini ab directly tool call karega
        "tools": [{"functionDeclarations": [OPEN_APP_TOOL]}]
    }
}


def enc(x):
    return json.dumps(x).encode()


# ── Transcript extract ────────────────────────────────────
# ✅ FIX 2: Dono transcript keys handle kiye
# Gemini Live API mein keys:
#   serverContent.inputTranscription.text  — user ki speech
#   serverContent.outputTranscription.text — ARIA ki speech  
#   serverContent.inputTranscript          — alternate key (older API)
def get_user_transcript(msg: dict) -> str:
    sc = msg.get("serverContent", {})

    # Primary key — newer API
    t = sc.get("inputTranscription", {})
    if isinstance(t, dict) and t.get("text", "").strip():
        return t["text"].strip()

    # Alternate key — older API versions
    t2 = sc.get("inputTranscript", "")
    if isinstance(t2, str) and t2.strip():
        return t2.strip()

    return ""


# ── App name extract (transcript fallback) ────────────────
# ✅ FIX 3: Yeh ab sirf fallback hai — primary method tool call hai
# Agar kisi reason se tool call na aaye toh transcript se try karo
def extract_app_name(transcript: str) -> str | None:
    text = transcript.lower().strip()

    # Hindi + English trigger words
    TRIGGERS = [
        # English
        "open", "launch", "start", "run",
        # Hindi/Hinglish
        "kholo", "kholdo", "khol do", "khol",
        "chalao", "chalaao", "chala", "chalu karo",
        "launch karo", "launch kro",
        "shuru karo", "shuru kro",
        "run karo", "run kro",
    ]

    # Longest first taaki "google chrome" > "chrome" pehle match ho
    KNOWN_APPS = sorted(
        list(APP_ALIASES.keys()),
        key=len, reverse=True
    )

    triggered_text = None
    for trigger in TRIGGERS:
        if trigger in text:
            after = text.split(trigger, 1)[-1].strip()
            # Filler words remove
            for filler in ["please", "kar", "karo", "kro", "do", "na",
                           "zara", "bhai", "yaar", "jaan", "baby"]:
                after = after.replace(filler, "").strip()
            triggered_text = after
            break

    if not triggered_text:
        return None

    # Known apps match
    for app in KNOWN_APPS:
        if app in triggered_text:
            return app

    # Fallback: pehla word
    words = triggered_text.split()
    return words[0] if words else None


# ── Main ARIA class ───────────────────────────────────────
class ARIA:
    def __init__(self):
        self.running = True
        self._ws     = None

    async def start(self):
        retry = 0
        while self.running:
            try:
                await self._session()
                retry = 0
            except Exception as e:
                retry += 1
                wait = min(2 ** retry, 30)
                print(f"[ARIA] Error: {e} — {wait}s mein reconnect...")
                await asyncio.sleep(wait)

    async def _session(self):
        async with websockets.connect(
            f"{WS_URL}?key={API_KEY}",
            max_size=None,
            ping_interval=20,
            ping_timeout=30,
            compression=None,
        ) as ws:
            self._ws = ws
            print("✅ Connected to ARIA")

            await ws.send(enc(SETUP))
            await ws.recv()
            print("✅ Setup complete — ab bolo!")

            # ✅ FIX 4: Audio queue se stutter fix
            import queue as _queue
            audio_q   = _queue.Queue()
            play_stop = asyncio.Event()

            def _play_thread():
                BUF = int(SPK_RATE * 0.20)
                buf = np.array([], dtype=np.float32)
                stream = sd.OutputStream(
                    samplerate=SPK_RATE, channels=1,
                    dtype="float32", blocksize=BUF, latency="high"
                )
                stream.start()
                while not play_stop.is_set():
                    try:
                        chunk = audio_q.get(timeout=0.15)
                        if chunk is None:
                            continue
                        buf = np.concatenate([buf, chunk])
                        while len(buf) >= BUF:
                            stream.write(buf[:BUF])
                            buf = buf[BUF:]
                    except _queue.Empty:
                        pass
                stream.stop(); stream.close()

            import threading
            play_t = threading.Thread(target=_play_thread, daemon=True)
            play_t.start()

            try:
                await asyncio.gather(
                    self._send_audio(ws),
                    self._recv(ws, audio_q),
                )
            finally:
                play_stop.set()
                audio_q.put(None)
                play_t.join(timeout=2.0)

    async def _send_audio(self, ws):
        with sd.InputStream(
            samplerate=MIC_RATE, channels=1,
            dtype="int16", blocksize=FRAMES, latency="low"
        ) as mic:
            print("🎤 Listening...")
            while self.running:
                pcm, _ = mic.read(FRAMES)
                await ws.send(enc({
                    "realtimeInput": {
                        "audio": {
                            "mimeType": "audio/pcm;rate=16000",
                            "data": base64.b64encode(pcm.tobytes()).decode()
                        }
                    }
                }))
                await asyncio.sleep(0.001)

    async def _recv(self, ws, audio_q):
        while self.running:
            try:
                raw = await ws.recv()
                msg = json.loads(raw)
            except websockets.exceptions.ConnectionClosed:
                break

            # ✅ FIX 1 APPLIED: Tool call handle karo — SABSE PEHLE CHECK
            # Gemini khud bolega kab app open karna hai
            for call in msg.get("toolCall", {}).get("functionCalls", []):
                name = call.get("name", "")
                args = call.get("args", {})
                call_id = call.get("id", "")

                if name == "open_app":
                    app_name = args.get("app_name", "")
                    print(f"🔧 Tool call: open_app('{app_name}')")
                    result = open_app(app_name)
                    print(f"   Result: {result}")

                    # Gemini ko tool result bhejo
                    await ws.send(enc({
                        "toolResponse": {
                            "functionResponses": [{
                                "id": call_id,
                                "name": name,
                                "response": {"result": result}
                            }]
                        }
                    }))

            # Transcript — user ki speech
            transcript = get_user_transcript(msg)
            if transcript:
                print(f"🗣️ You: {transcript}")

                # ✅ FIX 3: Transcript fallback — agar tool call na aaye
                app_name = extract_app_name(transcript)
                if app_name:
                    print(f"📱 Transcript fallback: open_app('{app_name}')")
                    result = open_app(app_name)
                    print(f"   Result: {result}")

            # ARIA ki speech transcript
            sc = msg.get("serverContent", {})
            aria_text = sc.get("outputTranscription", {})
            if isinstance(aria_text, dict) and aria_text.get("text", "").strip():
                print(f"🤖 ARIA: {aria_text['text'].strip()}")

            # Audio playback
            for part in sc.get("modelTurn", {}).get("parts", []):
                d = part.get("inlineData")
                if d and "audio/pcm" in d.get("mimeType", ""):
                    raw_bytes = base64.b64decode(d["data"])
                    pcm = np.frombuffer(raw_bytes, dtype=np.int16).astype(np.float32) / 32768.0
                    try:
                        audio_q.put_nowait(pcm)
                    except Exception:
                        pass


# ── Run ───────────────────────────────────────────────────
if __name__ == "__main__":
    aria = ARIA()
    asyncio.run(aria.start())